export function Button({ children, onClick, disabled, variant = "default", size = "md" }) {
  const styles = {
    default: "bg-blue-600 hover:bg-blue-700 text-white",
    destructive: "bg-red-600 hover:bg-red-700 text-white",
  };
  const base = "px-4 py-2 rounded text-sm";
  const cls = \`\${base} \${styles[variant] || ""} \${disabled ? "opacity-50 cursor-not-allowed" : ""}\`;

  return (
    <button className={cls} onClick={onClick} disabled={disabled}>
      {children}
    </button>
  );
}
