import React from "react";
import { Button } from "./ui/button";
import { typeOptions, statusOptions } from "../config/constants";

export default function AssetForm({ form, errors, isSubmitting, editingIndex, onChange, onSubmit }) {
  return <div>Form</div>;
}
