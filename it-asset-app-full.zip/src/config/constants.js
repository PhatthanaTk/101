export const typeOptions = [
  "Laptop",
  "Monitor",
  "Network",
  "Printer",
  "Other"
];

export const statusOptions = [
  "ใช้งานอยู่",
  "สำรอง",
  "ชำรุด",
  "จำหน่ายแล้ว"
];
