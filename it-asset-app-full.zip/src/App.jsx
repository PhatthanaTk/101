import React, { useState } from "react";
import { Button } from "./components/ui/button";
import AssetForm from "./components/AssetForm";
import { typeOptions, statusOptions } from "./config/constants";

export default function App() {
  return <div>IT Asset Tracker</div>;
}
